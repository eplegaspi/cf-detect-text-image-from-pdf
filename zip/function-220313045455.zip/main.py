

def cloud_storage():
    print("Hello world")